package MasterData;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import com.mysql.jdbc.Statement;

import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JScrollPane;

public class ItemSearch extends JDialog {
	private JTable tblitem;
	private JRadioButton rdobrand;
	private JRadioButton rdotype;
	private JRadioButton rdoboth;
	private JComboBox cbobrandname;
	private JComboBox cbotypename;
	private JButton btnSearch;
	private JButton btnShowall;
	private JButton btnPrint;
	private JButton btnClose;
	DefaultTableModel dtm = new DefaultTableModel();
	static clsDBConnection connect = new clsDBConnection();
	Statement ste = null ;
	Connection con = null;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			ItemSearch dialog = new ItemSearch();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public ItemSearch() throws ClassNotFoundException {
		setTitle("Item Searching");
		setBounds(100, 100, 741, 525);
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Item Search", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(10, 11, 705, 407);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		rdobrand = new JRadioButton("Brand");
		rdobrand.setBounds(24, 30, 109, 23);
		panel.add(rdobrand);
		
		rdotype = new JRadioButton("Type");
		rdotype.setBounds(164, 30, 109, 23);
		panel.add(rdotype);
		
		rdoboth = new JRadioButton("Brand & Type");
		rdoboth.setBounds(316, 30, 109, 23);
		panel.add(rdoboth);
		
		cbobrandname = new JComboBox();
		cbobrandname.setBounds(24, 68, 122, 22);
		panel.add(cbobrandname);
		
		cbotypename = new JComboBox();
		cbotypename.setBounds(166, 68, 122, 22);
		panel.add(cbotypename);
		
		btnSearch = new JButton("Search");
		btnSearch.setBounds(327, 68, 98, 23);
		panel.add(btnSearch);
		
		btnShowall = new JButton("Show All");
		btnShowall.setBounds(454, 68, 98, 23);
		panel.add(btnShowall);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(24, 112, 662, 268);
		panel.add(scrollPane);
		
		tblitem = new JTable();
		scrollPane.setViewportView(tblitem);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBounds(477, 429, 215, 46);
		getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		btnPrint = new JButton("Print");
		btnPrint.setBounds(10, 11, 89, 23);
		panel_1.add(btnPrint);
		
		btnClose = new JButton("Close");
		btnClose.setBounds(116, 11, 89, 23);
		panel_1.add(btnClose);
        try
        {
        	con=connect.getConnection();
        }
        catch(SQLException sqle)
        {
            System.out.println(sqle);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
	}
}
